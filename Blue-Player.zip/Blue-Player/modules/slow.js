// slow.js
(function () {
  "use strict";

  const MIN = 0.4;
  const MAX = 2.0;

  function clamp(v) {
    const n = Number(v);
    if (!isFinite(n)) return 1;
    return Math.max(MIN, Math.min(MAX, n));
  }

  function fmt(v) {
    const n = clamp(v);
    // show 1x, 0.95x, 1.25x (trim trailing zeros)
    let s = n.toFixed(2);
    s = s.replace(/\.00$/, "").replace(/(\.\d)0$/, "$1");
    return s + "x";
  }

  function setPreservesPitch(mediaEl, preserve) {
    // We WANT pitch changes => preserve = false
    try { if ("preservesPitch" in mediaEl) mediaEl.preservesPitch = preserve; } catch {}
    try { if ("mozPreservesPitch" in mediaEl) mediaEl.mozPreservesPitch = preserve; } catch {}
    try { if ("webkitPreservesPitch" in mediaEl) mediaEl.webkitPreservesPitch = preserve; } catch {}
  }

  function apply(mediaEl, rate) {
    const r = clamp(rate);
    try { setPreservesPitch(mediaEl, false); } catch {}
    try { mediaEl.playbackRate = r; } catch {}
    return r;
  }

  window.BPSlow = { MIN, MAX, clamp, fmt, apply, setPreservesPitch };
})();
