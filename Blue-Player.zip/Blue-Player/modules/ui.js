import { openDB, getAllTracks, putTrack, deleteTrack, getAllPlaylists, putPlaylist } from "./db.js?v=G12";
import { loadPrefs, savePrefs } from "./prefs.js?v=G12";
import { createSfx } from "./sfx.js?v=G12";
import { maybeExtractCover } from "./cover.js?v=G12";

export function boot(){
  const menuView = document.getElementById("menuView");
  const playlistView = document.getElementById("playlistView");
  const playlistDetailView = document.getElementById("playlistDetailView");
  const playerView = document.getElementById("playerView");
  const settingsView = document.getElementById("settingsView");

  const navMenu = document.getElementById("navMenu");
  const navPlaylist = document.getElementById("navPlaylist");
  const navPlayer = document.getElementById("navPlayer");
  const navSettings = document.getElementById("navSettings");

  const addBtn = document.getElementById("addBtn");
  const filePick = document.getElementById("filePick");

  const tracksList = document.getElementById("tracksList");
  const tracksEmpty = document.getElementById("tracksEmpty");
  const countPill = document.getElementById("countPill");
  const nowPill = document.getElementById("nowPill");

  const createPlBtn = document.getElementById("createPlBtn");
  const playlistsList = document.getElementById("playlistsList");

  const plBackBtn = document.getElementById("plBackBtn");
  const plTitlePill = document.getElementById("plTitlePill");
  const plAddBtn = document.getElementById("plAddBtn");
  const playlistTracksList = document.getElementById("playlistTracksList");
  const playlistTracksEmpty = document.getElementById("playlistTracksEmpty");

  const plPopup = document.getElementById("plPopup");
  const plNameInput = document.getElementById("plNameInput");
  const plCancelBtn = document.getElementById("plCancelBtn");
  const plCreateBtn = document.getElementById("plCreateBtn");

  const libPicker = document.getElementById("libPicker");
  const libPickerList = document.getElementById("libPickerList");
  const libPickerEmpty = document.getElementById("libPickerEmpty");
  const libCancelBtn = document.getElementById("libCancelBtn");
  const libAddBtn = document.getElementById("libAddBtn");

  const toast = document.getElementById("toast");

  const ctxMenu = document.getElementById("ctxMenu");
  const ctxDelete = document.getElementById("ctxDelete");
  const ctxRename = document.getElementById("ctxRename");

  const delConfirm = document.getElementById("delConfirm");
  const delText = document.getElementById("delText");
  const delCancel = document.getElementById("delCancel");
  const delOk = document.getElementById("delOk");

  const renamePopup = document.getElementById("renamePopup");
  const renameInput = document.getElementById("renameInput");
  const renameCancelBtn = document.getElementById("renameCancelBtn");
  const renameSaveBtn = document.getElementById("renameSaveBtn");

  const audio = document.getElementById("audio");
  const playPause = document.getElementById("playPause");
  const stopBtn = document.getElementById("stopBtn");
  const timePill = document.getElementById("timePill");
  const seek = document.getElementById("seek");

  const overlay = document.getElementById("overlay");
  const closeMenu = document.getElementById("closeMenu");
  const menuTrack = document.getElementById("menuTrack");
  const menuCover = document.getElementById("menuCover");
  const menuTimePill = document.getElementById("menuTimePill");
  const menuSeek = document.getElementById("menuSeek");

  const loopBtn = document.getElementById("loopBtn");
  const back10Btn = document.getElementById("back10");
  const fwd10Btn = document.getElementById("fwd10");
  const prevBtn = document.getElementById("prevBtn");
  const nextBtn = document.getElementById("nextBtn");
  const menuPlayPause = document.getElementById("menuPlayPause");

  const playerNowPill = document.getElementById("playerNowPill");
  const playerHint = document.getElementById("playerHint");
  const playerCover = document.getElementById("playerCover");
  const playerSeek = document.getElementById("playerSeek");
  const playerTimePill = document.getElementById("playerTimePill");
  const playerLoopBtn = document.getElementById("playerLoopBtn");
  const playerBack10 = document.getElementById("playerBack10");
  const playerPrevBtn = document.getElementById("playerPrevBtn");
  const playerPlayPause = document.getElementById("playerPlayPause");
  const playerNextBtn = document.getElementById("playerNextBtn");
  const playerFwd10 = document.getElementById("playerFwd10");

  const setNewenkirk = document.getElementById("setNewenkirk");
  const setSounds = document.getElementById("setSounds");
  const setAnims = document.getElementById("setAnims");

  let db = null;

  let prefs = loadPrefs();
  const sfx = createSfx(prefs);

  let tracks = [];
  let playlists = [];

  let currentId = null;
  let currentUrl = null;
  let menuForId = null;

  let currentTab = "menu";
  let currentPlaylistId = null;

  let seekingMain = false;
  let seekingMenu = false;
  let seekingPlayer = false;

  let pickerSelected = new Set();

  let ctxForId = null;
  let deleteTargetId = null;
  let renameTargetId = null;

  let playIntent = false;
  let stallTimer = null;
  let stallLastTime = 0;
  let stallLastPerf = 0;
  let stallRecovering = false;
  let currentTrackObj = null;

  function isPlaying(){
    return !!audio.src && !audio.paused && !audio.ended;
  }

  function shouldPlayUISfx(){
    return !!prefs.sounds && !isPlaying();
  }

  function applyPrefsUI(){
    document.body.classList.toggle("newenkirkOn", !!prefs.newenkirk);
    document.body.classList.toggle("animOn", !!prefs.anims);

    setNewenkirk.classList.toggle("on", !!prefs.newenkirk);
    setSounds.classList.toggle("on", !!prefs.sounds);
    setAnims.classList.toggle("on", !!prefs.anims);

    applyGlobalLoopToAudio();
    applyLoopUI();
  }

  function applyGlobalLoopToAudio(){
    audio.loop = !!prefs.globalLoop;
  }

  function setLoopUIFor(el, on){
    if (!el) return;
    if (on) el.classList.add("loopActive");
    else el.classList.remove("loopActive");
  }

  function applyLoopUI(){
    const on = !!prefs.globalLoop;
    setLoopUIFor(loopBtn, on);
    setLoopUIFor(playerLoopBtn, on);
  }

  function uid(){
    if (crypto && crypto.randomUUID) return crypto.randomUUID();
    return "id_" + Math.random().toString(16).slice(2) + "_" + Date.now();
  }

  function getPlaylist(id){
    return playlists.find(p => p.id === id) || null;
  }

  function showOnly(which){
    const views = [menuView, playlistView, playerView, settingsView];
    for (const v of views) v.classList.remove("show");
    which.classList.add("show");
  }

  function setActiveNav(tab){
    navMenu.classList.toggle("active", tab === "menu");
    navPlaylist.classList.toggle("active", tab === "playlist");
    navPlayer.classList.toggle("active", tab === "player");
    navSettings.classList.toggle("active", tab === "settings");
  }

  function goMenu(){
    currentTab = "menu";
    currentPlaylistId = null;
    setActiveNav("menu");
    showOnly(menuView);
    renderTracks();
  }

  function goPlaylistList(){
    currentTab = "playlist";
    currentPlaylistId = null;
    setActiveNav("playlist");
    showOnly(playlistView);
    renderPlaylists();
  }

  function openPanel(panelEl){
    panelEl.hidden = false;

    if (!prefs.anims){
      panelEl.classList.remove("animStart", "animIn", "animOut");
      return;
    }

    panelEl.classList.remove("animOut");
    panelEl.classList.add("animStart");
    panelEl.getBoundingClientRect();
    panelEl.classList.add("animIn");
    panelEl.classList.remove("animStart");
  }

  function closePanel(panelEl){
    if (panelEl.hidden) return;

    if (!prefs.anims){
      panelEl.hidden = true;
      panelEl.classList.remove("animStart", "animIn", "animOut");
      return;
    }

    panelEl.classList.remove("animIn");
    panelEl.classList.add("animOut");
    const done = () => {
      panelEl.hidden = true;
      panelEl.classList.remove("animOut");
      panelEl.removeEventListener("transitionend", done);
    };
    panelEl.addEventListener("transitionend", done);
  }

  function goPlaylistDetail(id){
    currentTab = "playlist";
    currentPlaylistId = id;
    setActiveNav("playlist");
    showOnly(playlistView);

    const p = getPlaylist(id);
    plTitlePill.textContent = p ? p.name : "Playlist";

    renderPlaylistTracks();
    openPanel(playlistDetailView);
  }

  function backFromPlaylistDetail(){
    closePanel(playlistDetailView);
  }

  function goPlayer(){
    currentTab = "player";
    currentPlaylistId = null;
    setActiveNav("player");
    showOnly(playerView);
    updatePlayerUI();
    updateTime();
    syncButtons();
  }

  function goSettings(){
    currentTab = "settings";
    currentPlaylistId = null;
    setActiveNav("settings");
    showOnly(settingsView);
  }

  function syncButtons(){
    const sym = (isPlaying()) ? "❚❚" : "▶";
    playPause.textContent = sym;
    menuPlayPause.textContent = sym;
    playerPlayPause.textContent = sym;
  }

  function fmtTime(s){
    if (!isFinite(s) || s < 0) return "0:00";
    const m = Math.floor(s / 60);
    const r = Math.floor(s % 60);
    return m + ":" + String(r).padStart(2, "0");
  }

  function setRangeFill(el, v){
    if (!el) return;
    const clamped = Math.max(0, Math.min(1000, Number(v) || 0));
    const pct = (clamped / 1000) * 100;
    el.style.background = `linear-gradient(to right, #0000CC 0%, #0000CC ${pct}%, #0000AA ${pct}%, #0000AA 100%)`;
  }

  function updateTime(){
    const cur = audio.currentTime || 0;
    const dur = audio.duration || 0;
    const text = fmtTime(cur) + " / " + fmtTime(dur);

    timePill.textContent = text;
    menuTimePill.textContent = text;
    playerTimePill.textContent = text;

    const v = dur > 0 ? Math.floor((cur / dur) * 1000) : 0;

    if (!seekingMain) seek.value = String(v);
    if (!seekingMenu) menuSeek.value = String(v);
    if (!seekingPlayer) playerSeek.value = String(v);

    setRangeFill(seek, seek.value);
    setRangeFill(menuSeek, menuSeek.value);
    setRangeFill(playerSeek, playerSeek.value);
  }

  function updateNowPill(){
    const current = tracks.find(x => x.id === currentId);
    const name = current ? current.name : "—";
    nowPill.textContent = "Now: " + name;
    playerNowPill.textContent = name;
  }

  function updateCountPill(){
    countPill.textContent = tracks.length + (tracks.length === 1 ? " track" : " tracks");
  }

  function updateMenuCover(id){
    const t = tracks.find(x => x.id === id);
    menuCover.src = (t && t.cover) ? t.cover : "BluePlayer.png";
  }

  function updatePlayerUI(){
    const t = tracks.find(x => x.id === currentId);
    if (!t){
      playerHint.hidden = true;
      playerCover.src = "BluePlayer.png";
      applyLoopUI();
      updateNowPill();
      return;
    }
    playerHint.hidden = true;
    playerCover.src = t.cover || "BluePlayer.png";
    applyLoopUI();
    updateNowPill();
  }

  function guessMime(file){
    const name = (file && file.name ? String(file.name) : "").toLowerCase();
    const t = (file && file.type ? String(file.type) : "").toLowerCase();
    if (t) {
      if (t === "audio/mp3") return "audio/mpeg";
      return t;
    }
    if (name.endsWith(".mp3")) return "audio/mpeg";
    if (name.endsWith(".m4a")) return "audio/mp4";
    if (name.endsWith(".aac")) return "audio/aac";
    if (name.endsWith(".wav")) return "audio/wav";
    if (name.endsWith(".ogg")) return "audio/ogg";
    if (name.endsWith(".mp4")) return "video/mp4";
    return "audio/mpeg";
  }

  /* ===== Safari stall recovery (same as before) ===== */
  function startStallWatch(){
    if (stallTimer) return;
    stallLastTime = audio.currentTime || 0;
    stallLastPerf = performance.now();
    stallTimer = setInterval(() => {
      if (!playIntent) {
        stallLastTime = audio.currentTime || 0;
        stallLastPerf = performance.now();
        return;
      }
      if (!audio.src || audio.paused || audio.ended) return;

      const ct = audio.currentTime || 0;
      if (ct > stallLastTime + 0.01) {
        stallLastTime = ct;
        stallLastPerf = performance.now();
        return;
      }

      const elapsed = performance.now() - stallLastPerf;
      if (elapsed < 1200) return;

      recoverFromStall().catch(() => {});
    }, 350);
  }

  async function recoverFromStall(){
    if (stallRecovering) return;
    stallRecovering = true;
    try {
      if (!audio.src) return;
      const before = audio.currentTime || 0;

      try { await audio.play(); } catch {}
      await new Promise(r => setTimeout(r, 140));

      const mid = audio.currentTime || 0;
      if (mid > before + 0.01) {
        stallLastTime = mid;
        stallLastPerf = performance.now();
        return;
      }

      try {
        const dur = audio.duration || 0;
        const bump = before + 0.05;
        audio.currentTime = (dur > 0) ? Math.min(dur, bump) : bump;
      } catch {}

      try { await audio.play(); } catch {}
      await new Promise(r => setTimeout(r, 160));

      const afterNudge = audio.currentTime || 0;
      if (afterNudge > before + 0.01) {
        stallLastTime = afterNudge;
        stallLastPerf = performance.now();
        return;
      }

      if (currentTrackObj && currentTrackObj.blob) {
        const keep = before;

        if (currentUrl) {
          try { URL.revokeObjectURL(currentUrl); } catch {}
          currentUrl = null;
        }

        const blob = currentTrackObj.blob;
        const type = currentTrackObj.type || blob.type || "audio/mpeg";
        const sliced = blob.slice(0, blob.size, type);

        currentUrl = URL.createObjectURL(sliced);

        try { audio.pause(); } catch {}
        try {
          audio.removeAttribute("src");
          audio.load();
        } catch {}

        audio.src = currentUrl;
        audio.preload = "auto";
        applyGlobalLoopToAudio();

        try { audio.load(); } catch {}

        await new Promise((resolve) => {
          let done = false;
          const fin = () => { if (!done){ done = true; resolve(); } };
          audio.addEventListener("loadedmetadata", fin, { once:true });
          audio.addEventListener("canplay", fin, { once:true });
          setTimeout(fin, 250);
        });

        try {
          const dur = audio.duration || 0;
          audio.currentTime = (dur > 0) ? Math.min(dur, keep) : keep;
        } catch {}

        try { await audio.play(); } catch {}
        await new Promise(r => setTimeout(r, 160));
      }

      stallLastTime = audio.currentTime || 0;
      stallLastPerf = performance.now();
    } finally {
      stallRecovering = false;
    }
  }

  async function reliablePlay(){
    playIntent = true;
    startStallWatch();

    try {
      await audio.play();
    } catch {
      await new Promise((resolve) => {
        let done = false;
        const fin = () => { if (!done){ done = true; resolve(); } };
        audio.addEventListener("canplay", fin, { once:true });
        audio.addEventListener("loadeddata", fin, { once:true });
        setTimeout(fin, 300);
      });
      try { await audio.play(); } catch {}
    }

    setTimeout(() => {
      if (!audio.src) return;
      if (playIntent && audio.paused) audio.play().catch(() => {});
    }, 220);
  }

  async function playTrack(id){
    const t = tracks.find(x => x.id === id);
    if (!t) return;

    currentTrackObj = t;
    currentId = id;

    playIntent = true;
    startStallWatch();

    try { audio.pause(); } catch {}
    try { audio.currentTime = 0; } catch {}

    if (currentUrl){
      try { URL.revokeObjectURL(currentUrl); } catch {}
      currentUrl = null;
    }

    const safeType = t.type || (t.blob && t.blob.type) || "audio/mpeg";
    const safeBlob = t.blob ? t.blob.slice(0, t.blob.size, safeType) : null;

    currentUrl = URL.createObjectURL(safeBlob || t.blob);

    try {
      audio.removeAttribute("src");
      audio.load();
    } catch {}

    audio.src = currentUrl;
    audio.preload = "auto";
    audio.muted = false;
    audio.volume = 1;
    audio.playbackRate = 1;

    try { audio.load(); } catch {}

    applyGlobalLoopToAudio();
    applyLoopUI();

    await reliablePlay();

    syncButtons();
    updateNowPill();
    updatePlayerUI();
    renderTracks();
    renderPlaylistTracks();
    updateTime();

    stallLastTime = audio.currentTime || 0;
    stallLastPerf = performance.now();
  }

  function openMenuAnimated(){
    overlay.hidden = false;
    if (!prefs.anims){
      overlay.classList.remove("animStart", "animOut");
      overlay.classList.add("animIn");
      return;
    }
    overlay.classList.remove("animOut");
    overlay.classList.add("animStart");
    overlay.getBoundingClientRect();
    overlay.classList.add("animIn");
    overlay.classList.remove("animStart");
  }

  function closeMenuAnimated(){
    if (overlay.hidden) return;
    if (!prefs.anims){
      overlay.hidden = true;
      overlay.classList.remove("animIn", "animStart", "animOut");
      return;
    }
    overlay.classList.remove("animIn");
    overlay.classList.add("animOut");
    const done = () => {
      overlay.hidden = true;
      overlay.classList.remove("animOut");
      overlay.removeEventListener("transitionend", done);
    };
    overlay.addEventListener("transitionend", done);
  }

  function openMenu(id){
    menuForId = id;
    const t = tracks.find(x => x.id === id);
    menuTrack.textContent = t ? (t.name || "Unknown") : "Menu";
    applyLoopUI();
    updateMenuCover(id);
    syncButtons();
    updateTime();
    openMenuAnimated();
  }

  function closeMenuNow(){
    closeMenuAnimated();
    menuForId = null;
  }

  function currentIndex(){
    if (!currentId) return -1;
    return tracks.findIndex(t => t.id === currentId);
  }

  async function playByIndex(i){
    if (!tracks.length) return;
    let idx = i;
    if (idx < 0) idx = tracks.length - 1;
    if (idx >= tracks.length) idx = 0;
    await playTrack(tracks[idx].id);
    updateMenuCover(currentId);
    updatePlayerUI();
  }

  function skipSeconds(delta){
    if (!audio.src) return;
    const dur = audio.duration || 0;
    const next = (audio.currentTime || 0) + delta;
    audio.currentTime = (dur > 0) ? Math.max(0, Math.min(dur, next)) : Math.max(0, next);
    updateTime();
  }

  function closeCtx(){
    ctxMenu.hidden = true;
    ctxForId = null;
  }

  function openCtxFor(id, anchorEl){
    ctxForId = id;
    const r = anchorEl.getBoundingClientRect();
    const menuW = 180;
    const menuH = 2 * 48 + 4;
    let left = Math.round(r.right - menuW);
    let top = Math.round(r.bottom + 6);
    left = Math.max(8, Math.min(left, window.innerWidth - menuW - 8));
    top = Math.max(8, Math.min(top, window.innerHeight - menuH - 8));
    ctxMenu.style.left = left + "px";
    ctxMenu.style.top = top + "px";
    ctxMenu.hidden = false;
  }

  function openDeleteConfirm(id){
    deleteTargetId = id;
    const t = tracks.find(x => x.id === id);
    const name = t ? (t.name || "Unknown") : "Unknown";
    delText.textContent = "Confirm deletion: " + name;
    delConfirm.hidden = false;
  }

  function closeDeleteConfirm(){
    delConfirm.hidden = true;
    deleteTargetId = null;
  }

  async function deleteTrackEverywhere(id){
    const idx = tracks.findIndex(t => t.id === id);
    if (idx < 0) return;

    const wasCurrent = (currentId === id);

    await deleteTrack(db, id);
    tracks.splice(idx, 1);

    for (const p of playlists){
      if (Array.isArray(p.trackIds) && p.trackIds.includes(id)){
        p.trackIds = p.trackIds.filter(x => x !== id);
        await putPlaylist(db, p);
      }
    }

    if (wasCurrent){
      playIntent = false;
      try { audio.pause(); } catch {}
      try { audio.currentTime = 0; } catch {}
      audio.src = "";
      if (currentUrl){
        try { URL.revokeObjectURL(currentUrl); } catch {}
        currentUrl = null;
      }
      currentId = null;
      currentTrackObj = null;
      syncButtons();
    }

    renderTracks();
    renderPlaylists();
    renderPlaylistTracks();
    updateNowPill();
    updatePlayerUI();
    updateTime();
  }

  function openRename(id){
    renameTargetId = id;
    const t = tracks.find(x => x.id === id);
    renameInput.value = t ? (t.name || "") : "";
    renamePopup.hidden = false;
    setTimeout(() => renameInput.focus(), 0);
  }

  function closeRename(){
    renamePopup.hidden = true;
    renameTargetId = null;
  }

  async function saveRenameNow(){
    if (!renameTargetId) return;
    const t = tracks.find(x => x.id === renameTargetId);
    if (!t) return;

    const next = (renameInput.value || "").trim();
    if (!next) return;

    t.name = next;
    await putTrack(db, t);

    renderTracks();
    renderPlaylistTracks();
    updateNowPill();

    if (!overlay.hidden && menuForId === renameTargetId){
      menuTrack.textContent = next;
    }
    closeRename();
  }

  function buildTrackRow(t){
    const row = document.createElement("div");
    row.className = "track" + (t.id === currentId ? " active" : "");
    row.dataset.id = t.id;

    const name = document.createElement("div");
    name.className = "name";
    name.textContent = t.name || "Unknown";

    const opts = document.createElement("button");
    opts.className = "miniBtn";
    opts.textContent = "⋮";
    opts.addEventListener("click", (e) => {
      e.stopPropagation();
      openCtxFor(t.id, opts);
    });

    row.appendChild(name);
    row.appendChild(opts);

    row.addEventListener("click", () => playTrack(t.id));
    row.addEventListener("dblclick", () => openMenu(t.id));

    return row;
  }

  function renderTracks(){
    tracksList.innerHTML = "";
    if (!tracks.length){
      tracksList.appendChild(tracksEmpty);
    } else {
      for (const t of tracks) tracksList.appendChild(buildTrackRow(t));
    }
    updateCountPill();
    updateNowPill();
  }

  function buildPlaylistRow(p){
    const row = document.createElement("div");
    row.className = "track" + (p.id === currentPlaylistId ? " active" : "");
    const name = document.createElement("div");
    name.className = "name";
    name.textContent = p.name || "Playlist";
    row.appendChild(name);
    row.addEventListener("click", () => goPlaylistDetail(p.id));
    row.addEventListener("dblclick", () => goPlaylistDetail(p.id));
    return row;
  }

  function renderPlaylists(){
    playlistsList.innerHTML = "";
    if (!playlists.length) return;
    const sorted = [...playlists].sort((a,b) => (a.createdAt||0) - (b.createdAt||0));
    for (const p of sorted) playlistsList.appendChild(buildPlaylistRow(p));
  }

  function renderPlaylistTracks(){
    playlistTracksList.innerHTML = "";
    const p = getPlaylist(currentPlaylistId);
    const ids = (p && Array.isArray(p.trackIds)) ? p.trackIds : [];
    const items = ids.map(id => tracks.find(t => t.id === id)).filter(Boolean);

    if (!items.length){
      playlistTracksList.appendChild(playlistTracksEmpty);
    } else {
      for (const t of items) playlistTracksList.appendChild(buildTrackRow(t));
    }
  }

  function buildPickRow(t){
    const row = document.createElement("div");
    row.className = "pickRow";
    row.dataset.id = t.id;

    const name = document.createElement("div");
    name.className = "name";
    name.textContent = t.name || "Unknown";

    row.appendChild(name);

    const refresh = () => row.classList.toggle("selected", pickerSelected.has(t.id));

    row.addEventListener("click", () => {
      if (pickerSelected.has(t.id)) pickerSelected.delete(t.id);
      else pickerSelected.add(t.id);
      refresh();
    });

    refresh();
    return row;
  }

  function renderLibraryPicker(){
    libPickerList.innerHTML = "";
    if (!tracks.length){
      libPickerList.appendChild(libPickerEmpty);
      return;
    }
    for (const t of tracks) libPickerList.appendChild(buildPickRow(t));
  }

  function openLibraryPicker(){
    pickerSelected = new Set();
    renderLibraryPicker();
    libPicker.hidden = false;
  }

  function closeLibraryPicker(){
    libPicker.hidden = true;
    pickerSelected = new Set();
  }

  function showErrorToast(){
    toast.hidden = false;
    toast.style.opacity = "1";
    const startFade = () => {
      const dur = 400;
      const t0 = performance.now();
      const step = (now) => {
        const p = Math.min(1, (now - t0) / dur);
        toast.style.opacity = String(1 - p);
        if (p < 1) requestAnimationFrame(step);
        else {
          toast.hidden = true;
          toast.style.opacity = "1";
        }
      };
      requestAnimationFrame(step);
    };
    setTimeout(startFade, 1000);
  }

  async function addSelectedToCurrentPlaylist(){
    const p = getPlaylist(currentPlaylistId);
    if (!p) return;

    const ids = Array.from(pickerSelected);
    if (!ids.length){
      showErrorToast();
      return;
    }

    if (!Array.isArray(p.trackIds)) p.trackIds = [];
    const existing = new Set(p.trackIds);

    for (const id of ids){
      if (!existing.has(id)){
        p.trackIds.push(id);
        existing.add(id);
      }
    }

    await putPlaylist(db, p);
    renderPlaylistTracks();
    closeLibraryPicker();
  }

  async function addFilesToLibrary(files){
    for (const f of files){
      const mime = guessMime(f);
      const buf = await f.arrayBuffer();
      const blob = new Blob([buf], { type: mime });

      const cover = await maybeExtractCover(f, blob);
      const id = uid();

      const obj = {
        id,
        name: f.name,
        type: mime,
        addedAt: Date.now(),
        cover: cover || null,
        blob
      };

      await putTrack(db, obj);
      tracks.push(obj);
    }

    tracks.sort((a,b) => (a.addedAt || 0) - (b.addedAt || 0));
    renderTracks();
  }

  function showCreatePlaylistPopup(){
    plPopup.hidden = false;
    plNameInput.value = "";
    setTimeout(() => plNameInput.focus(), 0);
  }

  function hideCreatePlaylistPopup(){
    plPopup.hidden = true;
  }

  async function createPlaylistFromInput(){
    const name = (plNameInput.value || "").trim();
    if (!name) return;
    const obj = { id: uid(), name, createdAt: Date.now(), trackIds: [] };
    await putPlaylist(db, obj);
    playlists.push(obj);
    playlists.sort((a,b) => (a.createdAt || 0) - (b.createdAt || 0));
    hideCreatePlaylistPopup();
    renderPlaylists();
  }

  async function toggleNewenkirk(){
    const next = !prefs.newenkirk;
    prefs.newenkirk = next;
    savePrefs(prefs);
    applyPrefsUI();
    if (next && shouldPlayUISfx()) await sfx.playSelect();
  }

  async function toggleSounds(){
    const next = !prefs.sounds;
    prefs.sounds = next;
    savePrefs(prefs);
    applyPrefsUI();
    if (next) {
      if (shouldPlayUISfx()) await sfx.playSelect();
      sfx.ensureSfxLoaded("click").catch(() => {});
      sfx.ensureSfxLoaded("select").catch(() => {});
    } else {
      sfx.drop();
    }
  }

  async function toggleAnims(){
    const next = !prefs.anims;
    prefs.anims = next;
    savePrefs(prefs);
    applyPrefsUI();
    if (next && shouldPlayUISfx()) await sfx.playSelect();
  }

  async function toggleGlobalLoop(){
    prefs.globalLoop = !prefs.globalLoop;
    savePrefs(prefs);
    applyGlobalLoopToAudio();
    applyLoopUI();
  }

  /* Nav clicks */
  navMenu.addEventListener("click", async () => {
    if (shouldPlayUISfx()) await sfx.playClick();
    goMenu();
  });
  navPlaylist.addEventListener("click", async () => {
    if (shouldPlayUISfx()) await sfx.playClick();
    if (currentPlaylistId) goPlaylistDetail(currentPlaylistId);
    else goPlaylistList();
  });
  navPlayer.addEventListener("click", async () => {
    if (shouldPlayUISfx()) await sfx.playClick();
    goPlayer();
  });
  navSettings.addEventListener("click", async () => {
    if (shouldPlayUISfx()) await sfx.playClick();
    goSettings();
  });

  setNewenkirk.addEventListener("click", () => { toggleNewenkirk().catch(() => {}); });
  setSounds.addEventListener("click", () => { toggleSounds().catch(() => {}); });
  setAnims.addEventListener("click", () => { toggleAnims().catch(() => {}); });

  addBtn.addEventListener("click", () => filePick.click());
  filePick.addEventListener("change", async () => {
    const files = Array.from(filePick.files || []);
    filePick.value = "";
    if (!files.length) return;
    await addFilesToLibrary(files);
  });

  createPlBtn.addEventListener("click", showCreatePlaylistPopup);
  plCancelBtn.addEventListener("click", hideCreatePlaylistPopup);
  plCreateBtn.addEventListener("click", createPlaylistFromInput);
  plNameInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") createPlaylistFromInput();
    if (e.key === "Escape") hideCreatePlaylistPopup();
  });

  plBackBtn.addEventListener("click", backFromPlaylistDetail);
  plAddBtn.addEventListener("click", () => {
    if (!currentPlaylistId) return;
    openLibraryPicker();
  });

  libCancelBtn.addEventListener("click", closeLibraryPicker);
  libAddBtn.addEventListener("click", addSelectedToCurrentPlaylist);
  libPicker.addEventListener("click", (e) => {
    if (e.target === libPicker) closeLibraryPicker();
  });

  ctxDelete.addEventListener("click", () => {
    if (!ctxForId) return;
    const id = ctxForId;
    closeCtx();
    openDeleteConfirm(id);
  });

  ctxRename.addEventListener("click", () => {
    if (!ctxForId) return;
    const id = ctxForId;
    closeCtx();
    openRename(id);
  });

  document.addEventListener("click", (e) => {
    if (!ctxMenu.hidden){
      if (!ctxMenu.contains(e.target)) closeCtx();
    }
  });

  delCancel.addEventListener("click", closeDeleteConfirm);
  delConfirm.addEventListener("click", (e) => {
    if (e.target === delConfirm) closeDeleteConfirm();
  });
  delOk.addEventListener("click", async () => {
    if (!deleteTargetId) return;
    const id = deleteTargetId;
    closeDeleteConfirm();
    await deleteTrackEverywhere(id);
  });

  renameCancelBtn.addEventListener("click", closeRename);
  renamePopup.addEventListener("click", (e) => {
    if (e.target === renamePopup) closeRename();
  });
  renameSaveBtn.addEventListener("click", saveRenameNow);
  renameInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") saveRenameNow();
    if (e.key === "Escape") closeRename();
  });

  menuPlayPause.addEventListener("click", async () => {
    playIntent = true;
    startStallWatch();

    if (!audio.src){
      if (menuForId) await playTrack(menuForId);
      else if (tracks.length) await playTrack(tracks[0].id);
      return;
    }
    if (audio.paused) await reliablePlay();
    else {
      playIntent = false;
      audio.pause();
    }
    syncButtons();
  });
  closeMenu.addEventListener("click", closeMenuNow);

  loopBtn.addEventListener("click", async () => { await toggleGlobalLoop(); });
  playerLoopBtn.addEventListener("click", async () => { await toggleGlobalLoop(); });

  back10Btn.addEventListener("click", () => skipSeconds(-10));
  fwd10Btn.addEventListener("click", () => skipSeconds(10));

  prevBtn.addEventListener("click", async () => {
    if (!tracks.length) return;
    if (!currentId){
      if (menuForId) await playTrack(menuForId);
      else await playTrack(tracks[0].id);
      return;
    }
    const idx = currentIndex();
    await playByIndex(idx - 1);
  });

  nextBtn.addEventListener("click", async () => {
    if (!tracks.length) return;
    if (!currentId){
      if (menuForId) await playTrack(menuForId);
      else await playTrack(tracks[0].id);
      return;
    }
    const idx = currentIndex();
    await playByIndex(idx + 1);
  });

  menuSeek.addEventListener("input", () => {
    seekingMenu = true;
    setRangeFill(menuSeek, menuSeek.value);
  });
  menuSeek.addEventListener("change", () => {
    const dur = audio.duration || 0;
    const pct = Number(menuSeek.value) / 1000;
    if (dur > 0) audio.currentTime = dur * pct;
    seekingMenu = false;
    updateTime();
  });

  playerPlayPause.addEventListener("click", async () => {
    playIntent = true;
    startStallWatch();

    if (!audio.src){
      if (currentId) await playTrack(currentId);
      else if (tracks.length) await playTrack(tracks[0].id);
      return;
    }
    if (audio.paused) await reliablePlay();
    else {
      playIntent = false;
      audio.pause();
    }
    syncButtons();
  });

  playerBack10.addEventListener("click", () => skipSeconds(-10));
  playerFwd10.addEventListener("click", () => skipSeconds(10));

  playerPrevBtn.addEventListener("click", async () => {
    if (!tracks.length) return;
    if (!currentId){
      await playTrack(tracks[0].id);
      return;
    }
    const idx = currentIndex();
    await playByIndex(idx - 1);
  });

  playerNextBtn.addEventListener("click", async () => {
    if (!tracks.length) return;
    if (!currentId){
      await playTrack(tracks[0].id);
      return;
    }
    const idx = currentIndex();
    await playByIndex(idx + 1);
  });

  playerSeek.addEventListener("input", () => {
    seekingPlayer = true;
    setRangeFill(playerSeek, playerSeek.value);
  });
  playerSeek.addEventListener("change", () => {
    const dur = audio.duration || 0;
    const pct = Number(playerSeek.value) / 1000;
    if (dur > 0) audio.currentTime = dur * pct;
    seekingPlayer = false;
    updateTime();
  });

  playPause.addEventListener("click", async () => {
    playIntent = true;
    startStallWatch();

    if (!audio.src){
      if (tracks.length) await playTrack(tracks[0].id);
      return;
    }
    if (audio.paused) await reliablePlay();
    else {
      playIntent = false;
      audio.pause();
    }
    syncButtons();
  });

  stopBtn.addEventListener("click", () => {
    playIntent = false;
    audio.pause();
    audio.currentTime = 0;
    syncButtons();
    updateTime();
  });

  seek.addEventListener("input", () => {
    seekingMain = true;
    setRangeFill(seek, seek.value);
  });
  seek.addEventListener("change", () => {
    const dur = audio.duration || 0;
    const pct = Number(seek.value) / 1000;
    if (dur > 0) audio.currentTime = dur * pct;
    seekingMain = false;
    updateTime();
  });

  audio.addEventListener("timeupdate", updateTime);
  audio.addEventListener("loadedmetadata", updateTime);

  audio.addEventListener("playing", () => {
    playIntent = true;
    startStallWatch();
    stallLastTime = audio.currentTime || 0;
    stallLastPerf = performance.now();
    syncButtons();
    updateTime();
  });

  audio.addEventListener("pause", () => {
    if (!audio.ended) playIntent = false;
    syncButtons();
    updateTime();
  });

  audio.addEventListener("ended", () => {
    playIntent = false;
    syncButtons();
    updateTime();
  });

  audio.addEventListener("stalled", () => recoverFromStall().catch(() => {}));
  audio.addEventListener("waiting", () => recoverFromStall().catch(() => {}));

  document.addEventListener("visibilitychange", () => {
    if (!document.hidden && playIntent && audio.src) {
      reliablePlay().catch(() => {});
    }
  });

  /* ===== BOOT: preload SFX FIRST, then load DB ===== */
  (async () => {
    applyPrefsUI();

    overlay.hidden = true;
    overlay.classList.remove("animStart", "animIn", "animOut");
    playlistDetailView.hidden = true;
    playlistDetailView.classList.remove("animStart", "animIn", "animOut");

    plPopup.hidden = true;
    libPicker.hidden = true;
    toast.hidden = true;

    ctxMenu.hidden = true;
    delConfirm.hidden = true;
    renamePopup.hidden = true;

    // 1) PRELOAD UI SOUNDS FIRST (ONLY Sound.wav + Select.wav)
    if (prefs.sounds) {
      // do these first before DB so they are "remembered" first
      await sfx.ensureSfxLoaded("click");
      await sfx.ensureSfxLoaded("select");
    }

    // 2) THEN load your library/playlists
    db = await openDB();

    tracks = await getAllTracks(db);
    tracks.sort((a,b) => (a.addedAt || 0) - (b.addedAt || 0));

    playlists = await getAllPlaylists(db);
    playlists.sort((a,b) => (a.createdAt || 0) - (b.createdAt || 0));

    renderTracks();
    renderPlaylists();
    updateNowPill();
    updatePlayerUI();
    updateTime();
    syncButtons();

    goMenu();

    applyGlobalLoopToAudio();
    applyLoopUI();
  })();
}