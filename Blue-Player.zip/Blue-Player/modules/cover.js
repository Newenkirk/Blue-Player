async function coverFromVideoBlob(blob){
  return new Promise((resolve) => {
    const url = URL.createObjectURL(blob);
    const v = document.createElement("video");
    v.src = url;
    v.muted = true;
    v.playsInline = true;
    v.preload = "auto";

    const cleanup = () => URL.revokeObjectURL(url);

    v.addEventListener("error", () => {
      cleanup();
      resolve(null);
    });

    v.addEventListener("loadeddata", () => {
      try {
        const target = Math.min(0.15, Math.max(0, (v.duration || 0) * 0.01));
        v.currentTime = target;
      } catch {
        cleanup();
        resolve(null);
      }
    });

    v.addEventListener("seeked", () => {
      try {
        const w = v.videoWidth || 0;
        const h = v.videoHeight || 0;
        if (!w || !h) {
          cleanup();
          resolve(null);
          return;
        }

        const size = Math.min(w, h);
        const sx = Math.floor((w - size) / 2);
        const sy = Math.floor((h - size) / 2);

        const c = document.createElement("canvas");
        c.width = size;
        c.height = size;

        const ctx = c.getContext("2d");
        ctx.drawImage(v, sx, sy, size, size, 0, 0, size, size);

        const dataUrl = c.toDataURL("image/png");
        cleanup();
        resolve(dataUrl);
      } catch {
        cleanup();
        resolve(null);
      }
    });
  });
}

export async function maybeExtractCover(file, blob){
  const name = (file.name || "").toLowerCase();
  const type = (file.type || "").toLowerCase();
  if (type === "video/mp4" || name.endsWith(".mp4") || type === "audio/mp4") {
    const cover = await coverFromVideoBlob(blob);
    return cover || null;
  }
  return null;
}
