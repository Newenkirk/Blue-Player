export function createSfx(prefsRef){
  let sfxCtx = null;
  let loading = { click:false, select:false };
  let buf = { click:null, select:null };

  function getCtx(){
    if (!sfxCtx) sfxCtx = new (window.AudioContext || window.webkitAudioContext)();
    return sfxCtx;
  }

  async function ensureSfxLoaded(kind){
    if (!prefsRef.sounds) return;
    if (buf[kind] || loading[kind]) return;

    loading[kind] = true;
    try {
      const ctx = getCtx();
      const url = (kind === "click") ? "./Sound.wav" : "./Select.wav";
      const res = await fetch(url, { cache: "no-store" });
      const arr = await res.arrayBuffer();
      buf[kind] = await ctx.decodeAudioData(arr.slice(0));
    } catch {
      buf[kind] = null;
    } finally {
      loading[kind] = false;
    }
  }

  async function play(kind){
    if (!prefsRef.sounds) return;
    try {
      const ctx = getCtx();
      if (ctx.state === "suspended") await ctx.resume().catch(() => {});
      await ensureSfxLoaded(kind);
      const b = buf[kind];
      if (!b) return;

      const src = ctx.createBufferSource();
      src.buffer = b;
      src.connect(ctx.destination);
      src.start(0);
    } catch {}
  }

  function drop(){
    buf.click = null;
    buf.select = null;
  }

  return {
    ensureSfxLoaded,
    playClick: () => play("click"),
    playSelect: () => play("select"),
    drop
  };
}