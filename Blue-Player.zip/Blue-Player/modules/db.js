export const DB_NAME = "blueplayer_db";
export const STORE_TRACKS = "tracks";
export const STORE_PLAYLISTS = "playlists";

export function openDB(){
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 2);
    req.onupgradeneeded = () => {
      const d = req.result;
      if (!d.objectStoreNames.contains(STORE_TRACKS)) d.createObjectStore(STORE_TRACKS, { keyPath: "id" });
      if (!d.objectStoreNames.contains(STORE_PLAYLISTS)) d.createObjectStore(STORE_PLAYLISTS, { keyPath: "id" });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function store(db, name, mode){
  return db.transaction(name, mode).objectStore(name);
}

export function putTrack(db, obj){
  return new Promise((resolve, reject) => {
    const r = store(db, STORE_TRACKS, "readwrite").put(obj);
    r.onsuccess = () => resolve(true);
    r.onerror = () => reject(r.error);
  });
}

export function deleteTrack(db, id){
  return new Promise((resolve, reject) => {
    const r = store(db, STORE_TRACKS, "readwrite").delete(id);
    r.onsuccess = () => resolve(true);
    r.onerror = () => reject(r.error);
  });
}

export function getAllTracks(db){
  return new Promise((resolve, reject) => {
    const r = store(db, STORE_TRACKS, "readonly").getAll();
    r.onsuccess = () => resolve(r.result || []);
    r.onerror = () => reject(r.error);
  });
}

export function putPlaylist(db, obj){
  return new Promise((resolve, reject) => {
    const r = store(db, STORE_PLAYLISTS, "readwrite").put(obj);
    r.onsuccess = () => resolve(true);
    r.onerror = () => reject(r.error);
  });
}

export function getAllPlaylists(db){
  return new Promise((resolve, reject) => {
    const r = store(db, STORE_PLAYLISTS, "readonly").getAll();
    r.onsuccess = () => resolve(r.result || []);
    r.onerror = () => reject(r.error);
  });
}
