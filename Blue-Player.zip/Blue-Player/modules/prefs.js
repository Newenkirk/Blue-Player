const PREF_KEY = "bp_prefs_v2";

const PREF_DEFAULTS = {
  newenkirk: false,
  sounds: true,
  anims: true,
  globalLoop: false
};

export function loadPrefs(){
  let prefs = { ...PREF_DEFAULTS };
  try {
    const raw = localStorage.getItem(PREF_KEY);
    if (!raw) return prefs;
    const obj = JSON.parse(raw);
    if (obj && typeof obj === "object") {
      prefs = { ...PREF_DEFAULTS, ...obj };
    }
  } catch {}
  return prefs;
}

export function savePrefs(prefs){
  try { localStorage.setItem(PREF_KEY, JSON.stringify(prefs)); } catch {}
}